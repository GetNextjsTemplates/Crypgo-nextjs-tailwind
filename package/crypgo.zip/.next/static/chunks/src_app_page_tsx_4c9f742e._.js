(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_4c9f742e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_4c9f742e._.js",
  "chunks": [
    "static/chunks/src_e0284405._.js",
    "static/chunks/node_modules_0f131af6._.js",
    "static/chunks/node_modules_slick-carousel_slick_eab2732a._.css"
  ],
  "source": "dynamic"
});
