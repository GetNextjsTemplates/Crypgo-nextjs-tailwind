(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__222216ca._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_62eaff38._.js",
    "static/chunks/node_modules_56d2b1ff._.js",
    "static/chunks/src_be6e671b._.js"
  ],
  "source": "dynamic"
});
